import { fileURLToPath } from "url";
import { dirname } from "path";
import express from "express";
import mysql from "mysql";
import cors from "cors";
import multer from "multer";
import path from "path";
import bcrypt from "bcrypt";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static("./file/"));
app.use(cors());
app.use(express.static("src"));
const port = 8080;

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "baktischool",
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    return cb(null, "./file/");
  },
  filename: (req, file, cb) => {
    return cb(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname),
    );
  },
});

const maxSize = 5 * 1024 * 1024;
var upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype == "image/png" ||
      file.mimetype == "image/jpg" ||
      file.mimetype == "image/jpeg" ||
      path.extname(file.originalname) !== ".docx" ||
      path.extname(file.originalname) !== ".pdf"
    ) {
      cb(null, true);
    } else {
      cb(null, false);
      return cb(new Error("only .png, .jgp .jpeg .docx .pdf format allowed"));
    }
  },
  limits: { fileSize: maxSize },
});
// admin login
function queryAsync(sql, params) {
  return new Promise((resolve, reject) => {
    db.query(sql, params, (error, results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });
}
app.get("/admin", async (req, res) => {
  const sql = "SELECT * FROM useradmin WHERE userName = ?";
  const { userName, passWord } = req.body;

  try {
    const result = await queryAsync(sql, [userName]);
    if (result[0].length > 0) {
      const storedHash = result[0][0].passWord;
      const passwordMatch = await bcrypt.compare(passWord, storedHash);
      if (passwordMatch) {
        res.json({ success: true });
      } else {
        res
          .status(401)
          .json({ success: false, error: "Wrong username or password" });
      }
    } else {
      res
        .status(401)
        .json({ success: false, error: "Wrong username or password" });
    }
  } catch (e) {
    console.error("Unexpected error:", e);
    res.status(500).json({ success: false, error: "Internal Server Error" });
  }
});

async function hashPassword(password) {
  const saltRounds = 10;
  return await bcrypt.hash(password, saltRounds);
}

app.post("/register", async (req, res) => {
  const { userName, passWord } = req.body;

  try {
    const hashedPassword = await hashPassword(passWord);
    const sql = "INSERT INTO useradmin (userName, passWord) VALUES (?, ?)";
    await queryAsync(sql, [userName, hashedPassword]);
    res.json({ success: true });
  } catch (error) {
    console.error("Unexpected error:", error);
    res.status(500).json({ success: false, error: "Internal Server Error" });
  }
});

// beranda
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
app.get("/", (req, res) => {
  app.use("/", express.static(path.join(__dirname, "image")));
  const sql = "SELECT ID, bHeadImg, kImg, description FROM home";
  db.query(sql, (err, data) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Internal Server Error");
    }
    res.status(200).json(data);
  });
});

app.post(
  "/admin/beranda",
  upload.fields([{ name: "kImg" }, { name: "bHeadImg" }]),
  (req, res) => {
    const sql = "INSERT INTO home (bHeadImg, kImg, description) VALUES (?)";
    const kImg = req.files["kImg"] ? req.files["kImg"][0]?.filename : null;
    const bHeadImg = req.files["bHeadImg"]
      ? req.files["bHeadImg"][0]?.filename
      : null;
    const description = req.body.description || null;

    const values = [bHeadImg, kImg, description];
    try {
      db.query(sql, [values], (err, data) => {
        if (err) {
          console.error("Database error:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }
        return res.json(data);
      });
    } catch (error) {
      console.error("Unexpected error:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  },
);

app.put(
  "/admin/beranda/:id",
  upload.fields([{ name: "kImg" }, { name: "bHeadImg" }]),
  (req, res) => {
    const id = req.params.id;
    const sql = "UPDATE home SET bHeadImg=?, kImg=?, description=? WHERE ID=?";
    const kImg = req.files["kImg"] ? req.files["kImg"][0]?.filename : null;
    const bHeadImg = req.files["bHeadImg"]
      ? req.files["bHeadImg"][0]?.filename
      : null;
    const description = req.body.description || null;

    const values = [bHeadImg, kImg, description, id];
    try {
      db.query(sql, values, (err, data) => {
        if (err) {
          console.error("Database error:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }
        return res.json({ Status: "Success" });
      });
    } catch (error) {
      console.error("Unexpected error:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  },
);

// profil
app.get("/profil", (req, res) => {
  const sql = "SELECT ID, kataPen, visimisi, struktur FROM profile";
  db.query(sql, (err, data) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Internal Server Error");
    }
    res.status(200).json(data);
  });
});
app.post("/admin/profil", upload.fields([{ name: "struktur" }]), (req, res) => {
  const sql = "INSERT INTO profile (kataPen, visimisi, struktur) VALUES (?)";
  const struktur = req.files["struktur"][0]?.filename;
  const kataPen = req.body.kataPen;
  const visimisi = req.body.visimisi;
  const values = [kataPen, visimisi, struktur];
  try {
    db.query(sql, [values], (err, data) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }
      return res.json(data);
    });
  } catch (error) {
    console.error("Unexpected error:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

app.put(
  "/admin/profil/:id",
  upload.fields([{ name: "struktur" }]),
  (req, res) => {
    const profileId = req.params.id;
    const struktur = req.files["struktur"]
      ? req.files["struktur"][0]?.filename
      : null;
    const kataPen = req.body.kataPen;
    const visimisi = req.body.visimisi;

    const sql =
      "UPDATE profile SET kataPen = ?, visimisi = ?, struktur = ? WHERE ID = ?";
    const values = [kataPen, visimisi, struktur, profileId];

    try {
      db.query(sql, values, (err, data) => {
        if (err) {
          console.error("Database error:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }
        return res.json(data);
      });
    } catch (error) {
      console.error("Unexpected error:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  },
);

// staff
app.get("/guru", (req, res) => {
  const sql =
    "SELECT ID, name, position, education, achievement, fotoGuru FROM teacher";
  db.query(sql, (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});

app.post("/admin/guru", upload.fields([{ name: "fotoGuru" }]), (req, res) => {
  const sql =
    "INSERT INTO teacher (name, position, education, achievement, fotoGuru) VALUES (?)";
  const fotoGuru = req.files["fotoGuru"][0]?.filename;
  const name = req.body.name;
  const position = req.body.position;
  const education = req.body.education;
  const achievement = req.body.achievement;
  const values = [name, position, education, achievement, fotoGuru];
  try {
    db.query(sql, [values], (err, data) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }
      return res.json(data);
    });
  } catch (error) {
    console.error("Unexpected error:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

app.put(
  "/admin/guru/:id",
  upload.fields([{ name: "fotoGuru" }]),
  (req, res) => {
    const teacherId = req.params.id;
    const fotoGuru = req.files["fotoGuru"]
      ? req.files["fotoGuru"][0]?.filename
      : null;
    const name = req.body.name;
    const position = req.body.position;
    const education = req.body.education;
    const achievement = req.body.achievement;

    const updateValues = {
      name,
      position,
      education,
      achievement,
      fotoGuru,
    };

    Object.keys(updateValues).forEach((key) => {
      if (updateValues[key] === null || updateValues[key] === undefined) {
        delete updateValues[key];
      }
    });

    const sql = "UPDATE teacher SET ? WHERE ID = ?";
    try {
      db.query(sql, [updateValues, teacherId], (err, data) => {
        if (err) {
          console.error("Database error:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }
        return res.json(data);
      });
    } catch (error) {
      console.error("Unexpected error:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  },
);

app.put(
  "/admin/berita/:id",
  upload.fields([{ name: "sampul" }]),
  (req, res) => {
    const newsId = req.params.id;
    const sql =
      "UPDATE news SET na=?, judulBerita=?, isiBerita=?, date=? WHERE ID=?";

    const sampul = req.files["sampul"]
      ? req.files["sampul"][0]?.filename
      : null;
    const judulBerita = req.body.judulBerita;
    const isiBerita = req.body.isiBerita;
    const date = req.body.date;
    const values = [sampul, judulBerita, isiBerita, date, newsId];

    try {
      db.query(sql, values, (err, data) => {
        if (err) {
          console.error("Database error:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }

        if (data.affectedRows === 0) {
          return res.status(404).json({ error: "News not found" });
        }

        return res.json({
          Status: "Success",
          message: "News updated successfully",
        });
      });
    } catch (error) {
      console.error("Unexpected error:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  },
);

// learning
app.post("/admin/learning", upload.none(), (req, res) => {
  const sql = "INSERT INTO learning (org) VALUES (?)";
  const org = req.body.org;
  const values = [org];
  try {
    db.query(sql, [values], (err, data) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }
      return res.json(data);
    });
  } catch (error) {
    console.error("Unexpected error:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

// berita
app.get("/berita/:id", (req, res) => {
  const sql = "SELECT ID, sampul, judulBerita, isiBerita, date FROM news";
  db.query(sql, (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});

app.post("/admin/berita/", upload.fields([{ name: "sampul" }]), (req, res) => {
  const sql =
    "INSERT INTO news (sampul, judulBerita, isiBerita, date) VALUES (?)";
  const sampul = req.files["sampul"][0]?.filename;
  const judulBerita = req.body.judulBerita;
  const isiBerita = req.body.isiBerita;
  const date = req.body.date;
  const values = [sampul, judulBerita, isiBerita, date];

  try {
    db.query(sql, [values], (err, data) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }
      return res.json(data);
    });
  } catch (error) {
    console.error("Unexpected error:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

app.put(
  "/admin/berita/:id",
  upload.fields([{ name: "sampul" }]),
  (req, res) => {
    const newsId = req.params.id;
    const sql =
      "UPDATE news SET sampul=?, judulBerita=?, isiBerita=?, date=? WHERE ID=?";

    const sampul = req.files["sampul"]
      ? req.files["sampul"][0]?.filename
      : null;
    const judulBerita = req.body.judulBerita;
    const isiBerita = req.body.isiBerita;
    const date = req.body.date;
    const values = [sampul, judulBerita, isiBerita, date, newsId];

    try {
      db.query(sql, values, (err, data) => {
        if (err) {
          console.error("Database error:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }

        if (data.affectedRows === 0) {
          return res.status(404).json({ error: "News not found" });
        }

        return res.json({
          Status: "Success",
          message: "News updated successfully",
        });
      });
    } catch (error) {
      console.error("Unexpected error:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  },
);

// pengumuman
app.get("/pengumuman/:id", (req, res) => {
  const sql = "SELECT id, descNotice, document FROM notice";
  db.query(sql, (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});

app.post(
  "/admin/pengumuman",
  upload.fields([{ name: "document" }]),
  (req, res) => {
    const sql = "INSERT INTO notice (descNotice, document) VALUES (?)";
    const document = req.files["document"][0]?.filename;
    const descNotice = req.body.descNotice;
    const values = [descNotice, document];

    try {
      db.query(sql, [values], (err, data) => {
        if (err) {
          console.error("Database error:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }
        return res.json(data);
      });
    } catch (error) {
      console.error("Unexpected error:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  },
);

app.put("/admin/berita/:id", (req, res) => {
  const sql = "update news set head = ?, subHead = ?, headImg = ? where id = ?";
  const values = [req.body.head, req.body.subHead, req.body.headImg];
  const id = req.params.id;
  db.query(sql, [...values, id], (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});

app.delete("/admin/berita/:id", (req, res) => {
  const sql = "delete from news where id = ?";
  const id = req.params.id;
  db.query(sql, [id], (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});

// ekstrakurikuler
app.get("/ekstrakurikuler", (req, res) => {
  const sql =
    "SELECT tittle, schedule, location, description, picture FROM extracurricular";
  db.query(sql, (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});
app.post(
  "/admin/ekstrakurikuler",
  upload.fields([{ name: "picture" }]),
  (req, res) => {
    const sql =
      "INSERT INTO extracurricular (tittle, schedule, location, description, picture) VALUES (?)";
    const picture = req.files["picture"][0]?.filename;
    const tittle = req.body.tittle;
    const schedule = req.body.schedule;
    const location = req.body.location;
    const description = req.body.description;
    const values = [tittle, schedule, location, description, picture];
    try {
      db.query(sql, [values], (err, data) => {
        if (err) {
          console.error("Database error:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }
        return res.json(data);
      });
    } catch (error) {
      console.error("Unexpected error:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  },
);

// kegiatan
app.post("/admin/kegiatan", upload.none(), (req, res) => {
  const sql = "INSERT INTO activities (kegiatan) VALUES (?)";
  const kegiatan = req.body.kegiatan;
  const values = [kegiatan];
  try {
    db.query(sql, [values], (err, data) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }
      return res.json(data);
    });
  } catch (error) {
    console.error("Unexpected error:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

// peserta didik

// rabu ceria
app.get("/rabuceria", (req, res) => {
  const sql = "SELECT description FROM rabuceria";
  db.query(sql, (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});
app.post("/admin/rabuceria", upload.none(), (req, res) => {
  const sql = "INSERT INTO rabuceria (description) VALUES (?)";
  const description = req.body.description;
  const values = [description];
  try {
    db.query(sql, [values], (err, data) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }
      return res.json(data);
    });
  } catch (error) {
    console.error("Unexpected error:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

// dikmensi
app.get("/dikmensi", (req, res) => {
  const sql = "SELECT isiDikmensi FROM dikmensi";
  db.query(sql, (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});

app.post("/admin/dikmensi", upload.none(), (req, res) => {
  const sql = "INSERT INTO dikmensi (isiDikmensi) VALUES (?)";
  const isiDikmensi = req.body.isiDikmensi;
  const values = [isiDikmensi];
  try {
    db.query(sql, [values], (err, data) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }
      return res.json(data);
    });
  } catch (error) {
    console.error("Unexpected error:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

// gallery
app.get("/galeri", (req, res) => {
  const sql = "SELECT judulGal, docGal FROM galeri";
  db.query(sql, (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});

app.post("/admin/galeri", upload.fields([{ name: "docGal" }]), (req, res) => {
  const sql = "INSERT INTO galeri (judulGal, docGal) VALUES (?)";
  const judulGal = req.body.judulGal;
  const docGal = req.files["docGal"][0]?.filename;
  const values = [judulGal, docGal];
  try {
    db.query(sql, [values], (err, data) => {
      if (err) {
        console.error("Database error:", err);
        return res.status(500).json({ error: "Internal Server Error" });
      }
      return res.json(data);
    });
  } catch (error) {
    console.error("Unexpected error:", error);
    return res.status(500).json({ error: "Internal Server Error" });
  }
});

// admin login
app.post("/admin", async (req, res) => {
  const sql = "SELECT * FROM useradmin WHERE userName = ? AND passWord = ?";
  const { userName, passWord } = req.body;
  try {
    const check = await db.promise().query(sql, [userName, passWord]);

    if (check) {
      res.json("success");
    } else {
      res.json("failed");
    }
  } catch (e) {
    res.json("failed");
  }
});

// siswa
app.get("/siswa", (req, res) => {
  const sql = "SELECT * FROM student";
  db.query(sql, (err, data) => {
    if (err) {
      return res.json(err);
    }
    return res.json(data);
  });
});

app.post(
  "/admin/siswa",
  upload.fields([{ name: "fotoMurid" }, { name: "dokumen" }]),
  (req, res) => {
    const sql =
      "INSERT INTO student (nama, kelas, nis, alamat, sakit, izin, tanpaKet, dokumen, fotoMurid) VALUES (?)";

    const nama = req.body.nama;
    const kelas = req.body.kelas;
    const nis = req.body.nis;
    const alamat = req.body.alamat;
    const sakit = req.body.sakit;
    const izin = req.body.izin;
    const tanpaKet = req.body.tanpaKet;
    const dokumen = req.files["dokumen"][0]?.filename;
    const fotoMurid = req.files["fotoMurid"][0]?.filename;
    const values = [
      nama,
      kelas,
      nis,
      alamat,
      sakit,
      izin,
      tanpaKet,
      dokumen,
      fotoMurid,
    ];
    try {
      db.query(sql, [values], (err, data) => {
        if (err) {
          console.error("Database error:", err);
          return res.status(500).json({ error: "Internal Server Error" });
        }
        return res.json(data);
      });
    } catch (error) {
      console.error("Unexpected error:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  },
);

app.listen(8080, () => {
  console.log(`Server Running at http://localhost:${port}`);
});
